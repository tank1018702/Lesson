﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Container
{
    class Program
    {
        static void Main(string[] args)
        {
            //TestList.TestList1();
            //TestList.TestList_Copy();
            TestList.TestList_Remove();

            //TestDict.TestDict1();
            //TestDict.TestDict_Copy();

            //TestDict.TestDict_Loop1();
            //TestDict.TestDict_Loop2();
            TestDict.TestDict_Loop3();

            Console.ReadKey();
        }
    }
}
